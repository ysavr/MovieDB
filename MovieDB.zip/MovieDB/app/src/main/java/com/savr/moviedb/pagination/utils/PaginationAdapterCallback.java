package com.savr.moviedb.pagination.utils;

public interface  PaginationAdapterCallback {
    void retryPageLoad();
}
